<div class="container">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <br>
                <div  style="display: block;">
                    <div class="single-package-item">
                        <a href="#"><img src="<?php echo base_url();?>assets/images/<?php echo $slider->image_link;?>" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="section-title text-center wow fadeInLeft">
                    <br>
                    <h1 class="text-left"><?php echo $slider->title ?></h1>
                </div>
                <div class="instruction-content wow fadeInRight">
                    <p><?php echo $slider->description; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!--food alergy section start-->
    <section class="food-alergy-section section-padding wow fadeInUp" id="food_alergy_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="food-alergy-thumb text-left w-100 wow slideInLeft">
                        <img  style="box-shadow: 0 0 10px #999; border: 2px solid var(--theme-color);" src="<?php echo base_url();?>/assets/images/food_alergy_1.jpg" alt="">
                    </div>
                </div>
                </div>
            </div>
        </div>
    </section>
<!--food alergy section end-->