<!-- single DETAILS SECTION START-->
<section class="single-details-section section-padding wow fadeInUp">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="single-post-area">
                
                    <div class="single-post-title">
                        <h2></h2>
                    </div>
                    <div class="single-post-content">
                        

<!--instruction section start-->
<section class="instruction-section section-padding wow fadeInUp">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center wow fadeInLeft">
                    <h1 class="text-left"><?php echo $settings->second_title; ?></h1>
                </div>
                <div class="instruction-content wow fadeInRight">
                    <p><?php echo $settings->second_content; ?></p>
                   <!-- <div class="template-btn wow fadeInLeft">
                        <a href="#">learn more</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--instruction section end-->

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- single DETAILS SECTION END-->